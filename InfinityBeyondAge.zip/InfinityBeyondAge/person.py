import random
from tkinter import messagebox


class Person:
    normal_sick = ["cold", "fever", "itchy allergy", "stomach ache", "sore throat", "headache"]
    serious_sick = ["cancer", "myocardial infarction", "stroke", "kidney failure", "Pneumonia"]
    congenital_sick = ["Down Syndrome", "cleft lip", "albinism", "muscular dystrophy"]

    def __init__(self, name, age, gender, image_path):
        self.name = name
        self.age = age
        self.image_path = image_path
        self.gender = gender
        self.job = "N/A"
        self.married = "single"
        self.couple = "N/A"
        self.die = "N"
        self.baby = 0
        if random.randint(0, 1000) > 950 and age == 0:
            self.health = random.choice(Person.congenital_sick)
        else:
            self.health = "healthy"
        self.money = 0
        self.salary = 0
        self.job_growth = 0
        self.max_salary = 0

    def grow(self):
        self.age += 1
        if self.age > 80 and random.random() < 0.1:
            return False
        return True

    def get_sick(self, sick_num):
        if sick_num > 700:
            self.health = random.choice(Person.normal_sick)
        elif sick_num > 900:
            self.health = random.choice(Person.serious_sick)

    def get_married(self):
        self.married = "married"

    def get_pregnant(self):
        self.health = "pregnant"

    def fall_in_love(self, name, sex):
        answer = messagebox.askyesno("Invitation",
                                     f"{name} would like to invite {self.name} for a drink. Accept?",
                                     icon="info")
        if answer:
            new_age = random.randint(18, self.age + 10)
            new_person = Person(name, new_age, sex, "")
            self.married = "in love"
            new_person.married = "in love"
            self.couple = new_person
            new_person.couple = self
            return new_person
        return None
