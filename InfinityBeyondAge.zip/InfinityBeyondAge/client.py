from person import Person
import random
import tkinter as tk
from tkinter import ttk, simpledialog, messagebox
import os
from PIL import Image, ImageTk


class FamilySimulatorGUI:
    def __init__(self, root):
        self.root = root
        self.root.title("Family Simulator")
        self.family = []
        self.year = 2025
        self.log_messages = []
        self.images = {}
        self.main_frame = tk.Frame(root)
        self.main_frame.pack(fill=tk.BOTH, expand=True)
        self.year_label = tk.Label(self.main_frame, text=f"Year: {self.year}", font=("Comic Sans MS", 30, "bold"))
        self.year_label.pack(pady=10)
        self.tree = ttk.Treeview(self.main_frame, height=5)
        self.tree.pack(fill=tk.BOTH, expand=True, padx=10, pady=5)
        self.tree["columns"] = ("info",)
        self.tree.column("#0", width=60, minwidth=60)
        self.tree.column("info", width=400, minwidth=200)
        s = ttk.Style()
        s.configure('Treeview', rowheight=100, font=("Comic Sans MS", 20, "bold"))
        self.tree.heading("#0", text="Icon")
        self.tree.heading("info", text="Member Info")
        self.log_text = tk.Text(self.main_frame, height=5)
        self.log_text.pack(fill=tk.BOTH, expand=True, padx=10, pady=5)
        self.button_frame = tk.Frame(self.main_frame)
        self.button_frame.pack(pady=10)
        self.next_year_button = tk.Button(self.button_frame, text="Next Year", command=self.simulate_year)
        self.next_year_button.pack(side=tk.LEFT, padx=10)
        self.exit_button = tk.Button(self.button_frame, text="Exit", command=self.root.quit)
        self.exit_button.pack(side=tk.LEFT, padx=10)
        self.initialize_family()

    def initialize_family(self):
        founder_name = simpledialog.askstring("Founder Name", "Please enter the family name:", parent=self.root)
        if not founder_name:
            founder_name = "Founder"
        sex = random.choice(["male", "female"])
        founder_image = f"/Users/louishan/PycharmProjects/InfinityBeyondAge/image/{sex}/1.jpg"
        founder = Person(founder_name, 20, sex, founder_image)
        self.family.append(founder)
        self.log_messages.append(f"Founder {founder.name} has joined the family.")
        self.update_display()

    def simulate_year(self):
        self.log_messages.clear()
        self.log_messages.append(f"==== Year: {self.year} ====")
        survivors = []
        for person in self.family:
            if person.grow():
                survivors.append(person)
            else:
                self.log_messages.append(f"{person.name} has died of old age.")
        self.family = survivors
        new_births = []
        girl_names = ["Jessica", "Jane", "Rain", "Evie", "Liana", "Onda", "Eila", "Nia", "Ann", "Vila", "Eira"]
        boy_names = ["Andrew", "Andy", "Louis", "Eric", "Levi", "Jack", "Tom", "Adam", "Jerome", "Butler", "James"]
        for person in self.family[:]:

            if person.age > 18 and random.random() < 0.2 and person.married == "single":

                if person.gender == "male":
                    partner_name = random.choice(girl_names)
                    image_path = "/Users/louishan/PycharmProjects/InfinityBeyondAge/image/female/"
                    sex = "female"
                else:
                    partner_name = random.choice(boy_names)
                    image_path = "/Users/louishan/PycharmProjects/InfinityBeyondAge/image/male/"
                    sex = "male"
                new_partner = person.fall_in_love(partner_name, sex)

                if new_partner is not None:
                    new_partner.image_path = image_path + str(random.choice([1, 2, 3, 4, 5, 6, 7])) + ".jpg"
                    self.family.append(new_partner)
                    self.log_messages.append(f"{person.name} and {new_partner.name} have fallen in love.")

            if person.married == "in love" and 20 <= person.age <= 40 and person.couple is not None:
                if random.random() < 0.4:
                    answer = messagebox.askyesno("Proposal",
                                                 f"{person.couple.name} is proposing to {person.name}. Accept?",
                                                 parent=self.root)
                    if answer:
                        person.get_married()
                        person.couple.get_married()
                        self.log_messages.append(f"{person.name} and {person.couple.name} got married.")

            if person.gender == "female" and person.married == "married" and person.health != "pregnant" and 20 <= person.age <= 40:
                if random.random() < 0.2:
                    person.get_pregnant()
                    self.log_messages.append(f"{person.name} is pregnant.")
            if person.health == "pregnant":
                if random.random() > 0.2 + person.baby * 0.3:
                    baby_name_input = simpledialog.askstring("Baby Name", f"Enter the name for {person.name}'s baby:",
                                                             parent=self.root)
                    if not baby_name_input:
                        baby_name_input = "Baby"
                    full_baby_name = baby_name_input
                    baby = Person(full_baby_name, 0, random.choice(["male", "female"]),
                                  "/Users/louishan/PycharmProjects/InfinityBeyondAge/image/infant/" + str(
                                      random.choice([1, 2, 3, 4, 5, 6, 7])) + ".jpg")
                    new_births.append(baby)
                    person.health = "healthy"
                    person.baby += 1
                    self.log_messages.append(f"{person.name} successfully gave birth. New baby: {baby.name}.")

                else:
                    self.family.remove(person)
                    self.log_messages.append(f"Tragically, {person.name} suffered complications during pregnancy.")

            if random.random() < 0.1:
                sick_num = random.randint(0, 1000)
                person.get_sick(sick_num)
                self.log_messages.append(f"{person.name} fell ill. Condition: {person.health}.")

        self.family.extend(new_births)
        self.update_display()
        self.year += 1
        self.year_label.config(text=f"Year: {self.year}")

    def update_display(self):
        for item in self.tree.get_children():
            self.tree.delete(item)
        self.images.clear()
        root_node = self.tree.insert("", "end", text="Family", values=("Family Members",))
        self.tree.item(root_node, open=True)
        for person in self.family:
            info = f"Name: {person.name} | Age: {person.age} | Gender: {person.gender} | Marital Status: {person.married} | Health: {person.health}"
            img = ImageTk.PhotoImage(Image.open(person.image_path).resize((100, 100)))
            self.images[id(person)] = img
            self.tree.insert(root_node, "end", text="", image=img, values=(info,))
        self.log_text.delete("1.0", tk.END)
        for msg in self.log_messages:
            self.log_text.insert(tk.END, msg + "\n")


if __name__ == "__main__":
    root = tk.Tk()
    root.tk_setPalette(background="lightblue")
    app = FamilySimulatorGUI(root)
    root.mainloop()