
import random
from PIL import Image, ImageTk
str1 = "/Users/louishan/PycharmProjects/InfinityBeyondAge/image/infant/"
str1 = str1[0:56]+"male/"+ str(random.choice([1, 2, 3, 4, 5, 6, 7])) + ".jpg"
print(str1)
image = Image.open(str1)
image.show()